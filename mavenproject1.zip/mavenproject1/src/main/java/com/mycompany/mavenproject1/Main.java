package com.mycompany.mavenproject1;




import javafx.application.Application;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.util.Callback;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

public class Main extends Application {
    Label l;
    private ObservableList<ObservableList> data;
    private TableView tableview;
    private String searchCriteria;
    Map<String,String> nameQuery = new HashMap<String,String>();
    private static final String BIRTHDAY_YEAR = "Birthday Year";
    private static final String EMPLOYEE_BIRTH_YEAR= "select FirstName, LastName from Employees where Year(BirthDate) = %s order by LastName";
    private static final String CUSTOMER_CITY = "Enter region to search customer";
    private static final String CUSTOMER_CITY_REGION = "select ContactName, City from customers where Region = '%s' order by City";
    private static final String ORDER_NUMBER_FOR_SUM = "Enter order number to get the total value";

    private static final String SUM_Of_ORDER = "select SUM(Quantity*(UnitPrice)-Discount) as TotalOrderCost from [ORder Details] where OrderId = '%s'";
    private static final String ORDER_NUMBER_FOR_DETAILS = "Enter order number to get order details";
    private static final String ORDER_DETAILS = "select orders.orderDate,\n" +
"orders.freight,\n" +
"oe.ProductName,\n" +
"oe.quantity,\n" +
"oe.UnitPrice,\n" +
"oe.discount from Orders, [order details extended] oe where oe.orderId = '%s' AND ORDERs.OrderID= oe.orderId";

    @Override
        public void start(Stage s)
        {
            tableview = new TableView();
            SplitPane splitPane = new SplitPane(tableview);
            // set title for the stage
            s.setTitle("Order Management");

            // create a menu
            Menu m = new Menu("Menu");

            // create menuitems
            MenuItem m1 = new MenuItem(ORDER_NUMBER_FOR_SUM);

            MenuItem m2 = new MenuItem(ORDER_NUMBER_FOR_DETAILS);
            MenuItem m3 = new MenuItem(BIRTHDAY_YEAR);
            MenuItem m4 = new MenuItem(CUSTOMER_CITY);

            // add menu items to menu
            m.getItems().add(m1);
            m.getItems().add(m2);
            m.getItems().add(m4);
            m.getItems().add(m3);

            // label to display events
            l= new Label("\t\t\t\t"
                    + "no menu item selected");

            // create events for menu items
            // action event
            EventHandler<ActionEvent> event = new EventHandler<ActionEvent>() {
                public void handle(ActionEvent e)
                {
                    showInputTextDialog();
                    MenuItem m = (MenuItem) e.getSource() ;

                    //l.setText("\t\t\t\t" + ((MenuItem)e.getSource()).getText() +
                           // " selected");
                    buildData(nameQuery.get(m.getText()));
                }
            };

            // add event
            m1.setOnAction(event);
            m2.setOnAction(event);
            m3.setOnAction(event);
            m4.setOnAction(event);

            // create a menubar
            MenuBar mb = new MenuBar();

            // add menu to menubar
            mb.getMenus().add(m);

            // create a VBox
            VBox vb = new VBox(mb, l);

            // create a scene
            Scene sc = new Scene(vb, 500, 300);
            BorderPane borderPane = new BorderPane(splitPane);

            borderPane.setTop(mb);

            Scene scene = new Scene(borderPane, 600, 400);

            s.setScene(scene);


            s.show();
            initialiseMap();
        }


    private void showInputTextDialog() {

        TextInputDialog dialog = new TextInputDialog("Enter Search Criteria");

        dialog.setTitle("Enter Search Criteria");
        dialog.setHeaderText("Enter Search Criteria");

        Optional<String> result = dialog.showAndWait();

        result.ifPresent(name -> {
            searchCriteria = name;
        });
    }
        public static void main(String args[])
        {
            // launch the application
            launch(args);
        }

    @SuppressWarnings("empty-statement")
    public void buildData(String s){
        Connection c ;
        data = FXCollections.observableArrayList();
        try{
            tableview.getColumns().clear();
            c = DataBaseConnection.getConnection();
            //SQL FOR SELECTING ALL OF CUSTOMER
            String SQL = String.format(s, searchCriteria);
            
            //ResultSet
            ResultSet rs = c.createStatement().executeQuery(SQL);
            ResultSetMetaData rsmd = rs.getMetaData();


            /**********************************
             * TABLE COLUMN ADDED DYNAMICALLY *
             **********************************/
            for(int i=0 ; i<rs.getMetaData().getColumnCount(); i++){
                //We are using non property style for making dynamic table
                final int j = i;
                TableColumn col = new TableColumn(rs.getMetaData().getColumnName(i+1));
                col.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<ObservableList,String>, ObservableValue<String>>(){
                    public ObservableValue<String> call(TableColumn.CellDataFeatures<ObservableList, String> param) {
                        Object o = param.getValue().get(j);
                        return  o == null ? new SimpleStringProperty("") : new SimpleStringProperty(o.toString());
                    }
                });

                tableview.getColumns().addAll(col);
                System.out.println("Column ["+i+"] ");
            }

            /********************************
             * Data added to ObservableList *
             ********************************/
            while(rs.next()){
                //Iterate Row
                ObservableList<String> row = FXCollections.observableArrayList();
                for(int i=1 ; i<=rs.getMetaData().getColumnCount(); i++){
                    //Iterate Column
                    row.add(rs.getString(i));
                }
                System.out.println("Row [1] added "+row );
                data.add(row);

            }

            //FINALLY ADDED TO TableView
            tableview.setItems(data);
        }catch(Exception e){
            e.printStackTrace();
            System.out.println("Error on Building Data");
        }
    }

    private void initialiseMap() {
        nameQuery.put(BIRTHDAY_YEAR,EMPLOYEE_BIRTH_YEAR);
        nameQuery.put(CUSTOMER_CITY,CUSTOMER_CITY_REGION);
        nameQuery.put(ORDER_NUMBER_FOR_SUM,SUM_Of_ORDER);
        nameQuery.put(ORDER_NUMBER_FOR_DETAILS, ORDER_DETAILS);
        
    }


    }

