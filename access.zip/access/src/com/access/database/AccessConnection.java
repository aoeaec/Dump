package com.access.database;

import java.sql.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class AccessConnection {


    public Connection getConnection() {
        try {

            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
        } catch (ClassNotFoundException cnfex) {

            System.out.println("Problem in loading or "
                    + "registering MS Access JDBC driver");
            cnfex.printStackTrace();
        }

        try {

            String msAccDB = "resources/exampleMDB.accdb";
            String dbURL = "jdbc:ucanaccess://"
                    + msAccDB;
            return DriverManager.getConnection(dbURL);
        } catch (Exception e) {
            System.out.println("Exception occurred while creating connection " + e.getStackTrace());
        }
        return null;
    }

    public List<String> getAllTableNames(){
        List<String> tableNames = new ArrayList<String>();
        DatabaseMetaData md = null;
        try {
            md = getConnection().getMetaData();
            ResultSet rs = md.getTables(null, null, "%", null);
            while (rs.next()) {
                tableNames.add(rs.getString(3));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return tableNames;
    }

    public String getTableContent(String tableName){
        StringBuilder stringBuilder = new StringBuilder();
        Map<Integer, List<String>> map = new HashMap<Integer, List<String>>();
        Statement statement = null;
        try{
            statement = getConnection().createStatement();
            ResultSet resultSet = statement.executeQuery("SELECT * FROM "+  tableName);
            ResultSetMetaData rsmd = resultSet.getMetaData();
            int columnsNumber = rsmd.getColumnCount();
            for (int i = 1; i <= columnsNumber; i++) {

                stringBuilder.append(rsmd.getColumnName(i)).append("\t");

            }
            stringBuilder.append("\n");
            while (resultSet.next()) {
                for (int i = 1; i <= columnsNumber; i++) {
                    String columnValue = resultSet.getString(i);
                    stringBuilder.append(columnValue + "  ");
                }
                stringBuilder.append("\n");
            }
        }
        catch(SQLException sqlex) {
            sqlex.printStackTrace();
        }
        return stringBuilder.toString();
    }

}