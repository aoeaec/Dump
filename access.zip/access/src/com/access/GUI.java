package com.access;

import com.access.database.AccessConnection;

import java.awt.*;
import java.awt.event.*;
import java.util.Map;

public class GUI extends Frame implements ActionListener
{
    Choice tableChooser;
    TextArea textArea;
    Frame f;

    AccessConnection accessConnection = new AccessConnection();
    GUI(){
        f= new Frame();
        tableChooser = prepareComboBox();
        tableChooser.setBounds(100,50, 75,30);
        f.add(tableChooser);
        f.setSize(400,400);
        Button b1=new Button("Submit");
        b1.setBounds(tableChooser.getX() + tableChooser.getWidth(),tableChooser.getY(),75,30);
        b1.addActionListener(this);
        f.add(b1);

        textArea = new TextArea();
        textArea.setBounds(20, 90,370,300);
        f.add(textArea);
        f.setLayout(null);
        f.setVisible(true);

        addWindowListener(new WindowAdapter(){
            public void windowClosing(WindowEvent e) {
                dispose();
                System.out.println("Closing");
            }
        });
    }
    public static void main(String args[])
    {
        new GUI();
    }

    public Choice prepareComboBox(){
        Choice tableChooser = new Choice();
        for(String tableName : new AccessConnection().getAllTableNames()){
            tableChooser.add(tableName);
        }
        return tableChooser;
    }


    @Override
    public void actionPerformed(ActionEvent actionEvent) {
        textArea.setText(accessConnection.getTableContent(tableChooser.getSelectedItem()));
        f.repaint();
    }
}
